package com.batrun;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** One screen: root folder, file browser, text viewer (md/txt/...), console for .bat/.cmd and commands. */
public class MainActivity extends Activity {
    private EditText rootField, cmdField;
    private TextView console;
    private ScrollView scroll;
    private BatRunner runner;
    private File runnerRoot;
    private File lastScript;
    private File browseDir;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();

    private final BatRunner.Out out = new BatRunner.Out() {
        public void println(final String s) { ui.post(new Runnable() { public void run() { append(s); } }); }
        public void clear() { ui.post(new Runnable() { public void run() { console.setText(""); } }); }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
        SharedPreferences sp = getPreferences(MODE_PRIVATE);
        String def = new File(Environment.getExternalStorageDirectory(), "Greymeat").getPath();
        rootField.setText(sp.getString("root", def));
        append("BatRun - runs .bat/.cmd files and shows .md/.txt files.\nC:\\ and every other drive letter map to the root folder above.\nWindows programs (.exe) can't run on Android.\n");
        Intent in = getIntent();
        if (in != null && in.getData() != null && "file".equals(in.getData().getScheme()))
            openFile(new File(in.getData().getPath()));
    }

    @Override protected void onResume() { super.onResume(); askStorage(); }

    private void askStorage() {
        if (Build.VERSION.SDK_INT >= 30) {
            if (!Environment.isExternalStorageManager()) {
                try {
                    Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + getPackageName()));
                    startActivity(i);
                } catch (Exception e) {
                    startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                }
            }
        } else if (Build.VERSION.SDK_INT >= 23) {
            requestPermissions(new String[]{
                    android.Manifest.permission.READ_EXTERNAL_STORAGE,
                    android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        }
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density); }

    private Button button(String t, View.OnClickListener l) {
        Button x = new Button(this); x.setText(t); x.setAllCaps(false); x.setOnClickListener(l);
        x.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        return x;
    }

    private void buildUi() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(8), dp(28), dp(8), dp(8));

        rootField = new EditText(this);
        rootField.setHint("Root folder (C:\\ maps here)");
        rootField.setSingleLine(true);
        rootField.setTextSize(14);
        col.addView(rootField);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(button("Browse", new View.OnClickListener() { public void onClick(View v) { browse(rootDir()); } }));
        row.addView(button("Run script", new View.OnClickListener() { public void onClick(View v) { runLast(); } }));
        row.addView(button("Clear", new View.OnClickListener() { public void onClick(View v) { console.setText(""); } }));
        col.addView(row);

        console = new TextView(this);
        console.setTypeface(Typeface.MONOSPACE);
        console.setTextSize(12);
        console.setTextIsSelectable(true);
        console.setPadding(dp(4), dp(4), dp(4), dp(4));
        scroll = new ScrollView(this);
        scroll.addView(console);
        col.addView(scroll, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        cmdField = new EditText(this);
        cmdField.setHint("command or script, e.g. dir  or  build.cmd");
        cmdField.setSingleLine(true);
        cmdField.setImeOptions(EditorInfo.IME_ACTION_GO);
        cmdField.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        cmdField.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            public boolean onEditorAction(TextView v, int id, android.view.KeyEvent e) { runCommand(); return true; }
        });
        bottom.addView(cmdField);
        Button go = new Button(this); go.setText("Go");
        go.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { runCommand(); } });
        bottom.addView(go);
        col.addView(bottom);
        setContentView(col);
    }

    private void append(String s) {
        console.append(s + "\n");
        scroll.post(new Runnable() { public void run() { scroll.fullScroll(View.FOCUS_DOWN); } });
    }

    private File rootDir() {
        String p = rootField.getText().toString().trim();
        File f = new File(p.isEmpty() ? Environment.getExternalStorageDirectory().getPath() : p);
        if (!f.isDirectory()) f.mkdirs();
        getPreferences(MODE_PRIVATE).edit().putString("root", f.getPath()).apply();
        return f;
    }

    private BatRunner runner() {
        File r = rootDir();
        if (runner == null || !r.equals(runnerRoot)) { runner = new BatRunner(r, out); runnerRoot = r; }
        return runner;
    }

    // ---------------------------------------------------------------- browser
    private void browse(final File dir) {
        browseDir = dir;
        File[] ls = dir.listFiles();
        final List<File> items = new ArrayList<File>();
        if (ls != null) { Arrays.sort(ls); for (File f : ls) if (f.isDirectory()) items.add(f); for (File f : ls) if (f.isFile()) items.add(f); }
        final File parent = dir.getParentFile();
        List<String> names = new ArrayList<String>();
        if (parent != null) names.add("..");
        for (File f : items) names.add((f.isDirectory() ? "[DIR] " : "") + f.getName());
        final boolean hasUp = parent != null;
        new AlertDialog.Builder(this)
                .setTitle(dir.getPath())
                .setItems(names.toArray(new String[0]), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface d, int which) {
                        if (hasUp && which == 0) { browse(parent); return; }
                        File f = items.get(which - (hasUp ? 1 : 0));
                        if (f.isDirectory()) browse(f); else openFile(f);
                    }
                })
                .setNegativeButton("Close", null)
                .show();
    }

    private static boolean isScript(File f) {
        String n = f.getName().toLowerCase(Locale.ROOT);
        return n.endsWith(".bat") || n.endsWith(".cmd");
    }

    private void openFile(final File f) {
        if (isScript(f)) {
            lastScript = f;
            new AlertDialog.Builder(this).setTitle(f.getName())
                    .setPositiveButton("Run", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int w) { runScript(f, ""); }
                    })
                    .setNeutralButton("View", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface d, int w) { showText(f); }
                    })
                    .setNegativeButton("Cancel", null).show();
        } else showText(f);
    }

    private void showText(File f) {
        if (f.length() > 2 * 1024 * 1024) { append("File too large to show: " + f.getName()); return; }
        try {
            StringBuilder sb = new StringBuilder();
            for (String s : BatRunner.readLines(f)) sb.append(s).append('\n');
            console.setText("");
            append("---- " + f.getPath() + " ----");
            append(sb.toString());
        } catch (Exception e) { append("Can't read " + f.getName() + ": " + e.getMessage()); }
    }

    // ---------------------------------------------------------------- running
    private void runLast() {
        if (lastScript == null) { append("Pick a .bat/.cmd with Browse first, or type its name below."); return; }
        runScript(lastScript, "");
    }

    private void runScript(final File f, final String args) {
        final BatRunner r = runner();
        append("\n> running " + f.getName());
        worker.execute(new Runnable() { public void run() { r.runScript(f, args); out.println("[done]"); } });
    }

    private void runCommand() {
        final String line = cmdField.getText().toString().trim();
        if (line.isEmpty()) return;
        cmdField.setText("");
        final BatRunner r = runner();
        append(r.prompt() + line);
        worker.execute(new Runnable() { public void run() { r.runLine(line); } });
    }
}
