package com.batrun;

import java.io.*;
import java.util.*;
import java.util.regex.*;

/**
 * A small interpreter for Windows .bat / .cmd scripts that works on plain files.
 * Drive letters (C:, D:, ...) all map to the chosen root folder. Windows programs
 * (.exe) cannot run on Android; they are reported, everything else is emulated.
 * No Android classes are used here, so it can be tested on any JVM.
 */
public class BatRunner {
    public interface Out { void println(String s); void clear(); }

    static class GotoEx extends RuntimeException {
        final String label;
        GotoEx(String l) { super(null, null, false, false); label = l; }
    }
    static class ExitEx extends RuntimeException {
        ExitEx() { super(null, null, false, false); }
    }
    static class Frame {
        final List<String> lines; final Map<String, Integer> labels; final String[] args; final File file;
        Frame(List<String> lines, String[] args, File file) {
            this.lines = lines; this.args = args; this.file = file;
            labels = new HashMap<String, Integer>();
            for (int i = 0; i < lines.size(); i++) {
                String t = lines.get(i).trim();
                if (t.startsWith(":") && !t.startsWith("::") && t.length() > 1) {
                    String n = t.substring(1).trim().split("\\s+")[0].toLowerCase(Locale.ROOT);
                    if (!labels.containsKey(n)) labels.put(n, i);
                }
            }
        }
        Frame(Frame base, String[] args) {
            this.lines = base.lines; this.labels = base.labels; this.args = args; this.file = base.file;
        }
    }
    private static class Blk { List<String> lines = new ArrayList<String>(); int end; String closing = ""; }

    private final File root;
    private File cwd;
    private final Out out;
    private Out cur;
    private final Map<String, String> vars = new HashMap<String, String>();
    private final Map<Character, String> forVars = new HashMap<Character, String>();
    private boolean echoOn = true, halt = false;
    private int errorLevel = 0, depth = 0;
    private long steps = 0;

    public BatRunner(File root, Out out) {
        this.root = norm(root); this.cwd = this.root; this.out = out; this.cur = out;
        vars.put("WINDIR", "C:\\Windows"); vars.put("SYSTEMROOT", "C:\\Windows");
        vars.put("USERPROFILE", "C:\\Users\\user"); vars.put("TEMP", "C:\\Temp"); vars.put("TMP", "C:\\Temp");
        vars.put("COMSPEC", "C:\\Windows\\System32\\cmd.exe"); vars.put("OS", "Windows_NT");
        vars.put("PROCESSOR_ARCHITECTURE", "AMD64");
    }

    // ---------------------------------------------------------------- public API
    public String prompt() { return winPath(cwd) + ">"; }

    public void runLine(String line) {
        Frame f = new Frame(new ArrayList<String>(), new String[]{"cmd"}, null);
        halt = false; steps = 0; boolean eo = echoOn; echoOn = false;
        try { execCommand(f, line); }
        catch (GotoEx g) { out.println("goto only works inside a script."); }
        catch (ExitEx e) { /* ignore */ }
        finally { echoOn = eo; cur = out; }
    }

    public void runScript(File script, String argLine) {
        halt = false; steps = 0; echoOn = true; depth = 0;
        try {
            List<String> a = new ArrayList<String>();
            if (argLine != null) a.addAll(toks(argLine));
            runScriptFile(norm(script), a);
        } catch (Exception e) { out.println("Error: " + e); }
        finally { cur = out; }
    }

    // ---------------------------------------------------------------- paths
    static File norm(File f) {
        String p = f.getAbsolutePath().replace('\\', '/');
        LinkedList<String> st = new LinkedList<String>();
        for (String s : p.split("/")) {
            if (s.isEmpty() || s.equals(".")) continue;
            if (s.equals("..")) { if (!st.isEmpty()) st.removeLast(); } else st.add(s);
        }
        StringBuilder b = new StringBuilder();
        for (String s : st) b.append('/').append(s);
        return new File(b.length() == 0 ? "/" : b.toString());
    }

    String winPath(File f) {
        String r = norm(f).getPath(), base = root.getPath(), rel;
        String pre = base.equals("/") ? "/" : base + "/";
        if (r.equals(base)) rel = "";
        else if (r.startsWith(pre)) rel = r.substring(pre.length());
        else rel = r.substring(1);
        return "C:\\" + rel.replace('/', '\\');
    }

    File toFile(String p) {
        p = unq(p);
        boolean abs;
        if (p.length() >= 2 && Character.isLetter(p.charAt(0)) && p.charAt(1) == ':') {
            p = p.substring(2);
            abs = p.isEmpty() || p.startsWith("\\") || p.startsWith("/");
        } else abs = p.startsWith("\\") || p.startsWith("/");
        p = p.replace('\\', '/');
        if (abs && (p.equals(root.getPath()) || p.startsWith(root.getPath() + "/"))) return norm(new File(p));
        return norm(new File(abs ? root : cwd, p));
    }

    // ---------------------------------------------------------------- text helpers
    static String unq(String s) {
        s = s.trim();
        if (s.length() >= 2 && s.startsWith("\"") && s.endsWith("\"")) return s.substring(1, s.length() - 1);
        return s;
    }

    static List<String> toks(String s) {
        List<String> r = new ArrayList<String>();
        StringBuilder b = new StringBuilder(); boolean q = false, has = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '"') { q = !q; has = true; continue; }
            if (!q && (c == ' ' || c == '\t' || c == ',')) {
                if (has || b.length() > 0) { r.add(b.toString()); b.setLength(0); has = false; }
                continue;
            }
            b.append(c);
        }
        if (has || b.length() > 0) r.add(b.toString());
        return r;
    }

    /** returns {first token (unquoted), rest (trimmed, raw)} */
    static String[] splitFirst(String s) {
        s = s.trim();
        StringBuilder b = new StringBuilder(); boolean q = false; int i = 0;
        for (; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '"') { q = !q; continue; }
            if (!q && (c == ' ' || c == '\t')) break;
            b.append(c);
        }
        return new String[]{b.toString(), i < s.length() ? s.substring(i).trim() : ""};
    }

    static int indexOfUnquoted(String s, String what) {
        boolean q = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '"') q = !q;
            else if (!q && c == '^') i++;
            else if (!q && s.startsWith(what, i)) return i;
        }
        return -1;
    }

    static String unescape(String s) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '^' && i + 1 < s.length()) { b.append(s.charAt(++i)); } else b.append(c);
        }
        return b.toString();
    }

    static String wild(String name) {
        StringBuilder b = new StringBuilder();
        for (char c : name.toCharArray()) {
            if (c == '*') b.append(".*"); else if (c == '?') b.append('.');
            else b.append(Pattern.quote(String.valueOf(c)));
        }
        return b.toString();
    }

    // ---------------------------------------------------------------- variable expansion
    private String expand(String s, Frame f) {
        StringBuilder b = new StringBuilder(); int n = s.length();
        for (int i = 0; i < n; i++) {
            char c = s.charAt(i);
            if (c != '%') { b.append(c); continue; }
            if (i + 1 < n && s.charAt(i + 1) == '%') {
                if (i + 2 < n && Character.isLetter(s.charAt(i + 2))) {
                    Character v = s.charAt(i + 2);
                    if (forVars.containsKey(v)) { b.append(forVars.get(v)); i += 2; }
                    else { b.append("%%"); i += 1; }   // keep %%X until the loop defines X
                } else { b.append('%'); i += 1; }
                continue;
            }
            if (i + 1 < n && s.charAt(i + 1) == '~') {
                int j = i + 2; StringBuilder mods = new StringBuilder();
                while (j < n && Character.isLetter(s.charAt(j))) { mods.append(s.charAt(j)); j++; }
                if (j < n && Character.isDigit(s.charAt(j))) {
                    b.append(modArg(f, s.charAt(j) - '0', mods.toString().toLowerCase(Locale.ROOT)));
                    i = j; continue;
                }
            }
            if (i + 1 < n && Character.isDigit(s.charAt(i + 1))) {
                int k = s.charAt(i + 1) - '0';
                b.append(k < f.args.length && f.args[k] != null ? f.args[k] : ""); i++; continue;
            }
            if (i + 1 < n && s.charAt(i + 1) == '*') {
                StringBuilder a = new StringBuilder();
                for (int k = 1; k < f.args.length; k++) { if (k > 1) a.append(' '); a.append(f.args[k]); }
                b.append(a); i++; continue;
            }
            int e = s.indexOf('%', i + 1);
            if (e > i + 1) {
                String name = s.substring(i + 1, e);
                if (name.indexOf(' ') < 0 && name.indexOf(':') < 0) {
                    b.append(lookup(name)); i = e; continue;
                }
            }
            b.append('%');
        }
        String r = b.toString();
        if (r.indexOf('!') >= 0) {
            Matcher m = Pattern.compile("!([A-Za-z0-9_]+)!").matcher(r);
            StringBuffer sb = new StringBuffer();
            while (m.find()) {
                String v = vars.get(m.group(1).toUpperCase(Locale.ROOT));
                m.appendReplacement(sb, Matcher.quoteReplacement(v != null ? v : m.group()));
            }
            m.appendTail(sb); r = sb.toString();
        }
        return r;
    }

    private String lookup(String name) {
        String u = name.toUpperCase(Locale.ROOT);
        if (u.equals("CD")) return winPath(cwd).replaceAll("(?<=[^:])\\\\$", "");
        if (u.equals("ERRORLEVEL")) return String.valueOf(errorLevel);
        if (u.equals("RANDOM")) return String.valueOf(new Random().nextInt(32768));
        String v = vars.get(u);
        return v == null ? "" : v;
    }

    private String modArg(Frame f, int idx, String mods) {
        String full;
        if (idx == 0) full = f.file != null ? winPath(f.file) : winPath(cwd) + "cmd";
        else {
            String a = idx < f.args.length && f.args[idx] != null ? unq(f.args[idx]) : "";
            if (a.isEmpty()) return "";
            full = winPath(toFile(a));
        }
        if (mods.isEmpty()) return full;
        int bs = full.lastIndexOf('\\');
        String dir = full.substring(0, bs + 1), name = full.substring(bs + 1);
        int dot = name.lastIndexOf('.');
        String nm = dot > 0 ? name.substring(0, dot) : name, ext = dot > 0 ? name.substring(dot) : "";
        StringBuilder r = new StringBuilder();
        if (mods.contains("f")) return full;
        if (mods.contains("d")) r.append("C:");
        if (mods.contains("p")) r.append(dir.length() >= 2 ? dir.substring(2) : dir);
        if (mods.contains("n")) r.append(nm);
        if (mods.contains("x")) r.append(ext);
        return r.toString();
    }

    // ---------------------------------------------------------------- running
    private void runScriptFile(File file, List<String> args) throws IOException {
        if (depth > 40) { out.println("Too many nested calls."); return; }
        List<String> lines = readLines(file);
        String[] a = new String[Math.max(10, args.size() + 1)];
        a[0] = winPath(file);
        for (int i = 0; i < args.size(); i++) a[i + 1] = args.get(i);
        depth++;
        try { runFrame(new Frame(lines, a, file), 0); } finally { depth--; }
    }

    static List<String> readLines(File f) throws IOException {
        BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(f), "UTF-8"));
        try {
            List<String> l = new ArrayList<String>(); String s; boolean first = true;
            while ((s = r.readLine()) != null) {
                if (first && s.startsWith("\uFEFF")) s = s.substring(1);
                first = false; l.add(s);
            }
            return l;
        } finally { r.close(); }
    }

    private void runFrame(Frame f, int start) {
        while (!halt) {
            try { execLines(f, f.lines, start); return; }
            catch (GotoEx g) {
                Integer idx = f.labels.get(g.label);
                if (idx == null) { out.println("The system cannot find the batch label specified - " + g.label); return; }
                start = idx + 1;
            }
            catch (ExitEx e) { return; }
        }
    }

    private Blk gather(List<String> L, int from) {
        Blk b = new Blk(); int depthB = 1, j = from;
        for (; j < L.size(); j++) {
            String t = L.get(j).trim();
            boolean st = t.startsWith(")"), en = t.endsWith("(");
            if (depthB == 1 && st) { b.closing = t; break; }
            if (st) depthB--;
            if (en) depthB++;
            b.lines.add(L.get(j));
        }
        b.end = j; return b;
    }

    private void execLines(Frame f, List<String> L, int start) {
        for (int i = start; i < L.size(); i++) {
            if (halt) return;
            if (++steps > 500000) { out.println("Aborted: too many steps."); halt = true; return; }
            String t = L.get(i).trim();
            if (t.isEmpty() || t.startsWith(":")) continue;
            String tt = t.startsWith("@") ? t.substring(1).trim() : t;
            String ltt = tt.toLowerCase(Locale.ROOT);
            if (ltt.equals("rem") || ltt.startsWith("rem ")) continue;
            if (tt.endsWith("(")) {
                Blk b = gather(L, i + 1);
                Blk e = null; String rest;
                if (b.closing.toLowerCase(Locale.ROOT).matches("^\\)\\s*else\\s*\\($")) {
                    e = gather(L, b.end + 1);
                    rest = e.closing.length() > 0 ? e.closing.substring(1).trim() : "";
                    i = e.end;
                } else {
                    rest = b.closing.length() > 0 ? b.closing.substring(1).trim() : "";
                    i = b.end;
                }
                dispatchBlock(f, tt.substring(0, tt.length() - 1).trim(), b.lines, e == null ? null : e.lines, rest);
                continue;
            }
            execCommand(f, t);
        }
    }

    private void dispatchBlock(final Frame f, String head, final List<String> thenB, final List<String> elseB, String rest) {
        final String eh = expand(head, f), lh = eh.toLowerCase(Locale.ROOT);
        Runnable body;
        if (lh.startsWith("if ")) {
            Object[] c = parseCond(eh.substring(3));
            final List<String> blk = ((Boolean) c[0]) ? thenB : elseB;
            body = new Runnable() { public void run() { if (blk != null) execLines(f, blk, 0); } };
        } else if (lh.startsWith("for ")) {
            body = new Runnable() { public void run() { forLine(f, eh, thenB); } };
        } else if (eh.isEmpty()) {
            body = new Runnable() { public void run() { execLines(f, thenB, 0); } };
        } else {
            out.println("Unsupported block: " + head); return;
        }
        if (rest.startsWith(">")) {
            boolean app = rest.startsWith(">>");
            withRedirect(rest.substring(app ? 2 : 1).trim(), app, body);
        } else body.run();
    }

    private void withRedirect(String target, boolean app, Runnable r) {
        Out saved = cur; final StringBuilder cap = new StringBuilder();
        cur = new Out() {
            public void println(String s) { cap.append(s).append("\r\n"); }
            public void clear() { }
        };
        try { r.run(); } finally { cur = saved; }
        target = unq(target);
        if (target.equalsIgnoreCase("nul") || target.startsWith("&")) return;
        try { writeFile(toFile(target), cap.toString(), app); }
        catch (IOException e) { out.println("Access is denied: " + target); errorLevel = 1; }
    }

    private static void writeFile(File f, String text, boolean append) throws IOException {
        File p = f.getParentFile(); if (p != null) p.mkdirs();
        FileOutputStream o = new FileOutputStream(f, append);
        try { o.write(text.getBytes("UTF-8")); } finally { o.close(); }
    }

    private void execCommand(Frame f, String raw) {
        if (halt) return;
        String line = raw.trim(); boolean quiet = false;
        while (line.startsWith("@")) { quiet = true; line = line.substring(1).trim(); }
        if (line.isEmpty()) return;
        line = expand(line, f);
        if (echoOn && !quiet) out.println(winPath(cwd) + ">" + line);
        execChain(f, line);
    }

    private void execChain(Frame f, String line) {
        List<String[]> parts = new ArrayList<String[]>();
        boolean q = false; StringBuilder b = new StringBuilder(); String sep = "";
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == '"') { q = !q; b.append(c); continue; }
            if (!q && c == '^' && i + 1 < line.length()) { b.append(c).append(line.charAt(++i)); continue; }
            if (!q && c == '&') {
                parts.add(new String[]{sep, b.toString()}); b.setLength(0);
                if (i + 1 < line.length() && line.charAt(i + 1) == '&') { sep = "&&"; i++; } else sep = "&";
                continue;
            }
            if (!q && c == '|' && i + 1 < line.length() && line.charAt(i + 1) == '|') {
                parts.add(new String[]{sep, b.toString()}); b.setLength(0); sep = "||"; i++; continue;
            }
            b.append(c);
        }
        parts.add(new String[]{sep, b.toString()});
        for (String[] p : parts) {
            if (halt) return;
            if (p[0].equals("&&") && errorLevel != 0) continue;
            if (p[0].equals("||") && errorLevel == 0) continue;
            execSimple(f, p[1].trim());
        }
    }

    private void execSimple(Frame f, String s) {
        if (s.isEmpty()) return;
        String l = s.toLowerCase(Locale.ROOT);
        if (l.startsWith("if ")) { ifLine(f, s.substring(3).trim()); return; }
        if (l.startsWith("for ")) { forLine(f, s, null); return; }
        builtin(f, s);
    }

    // ---------------------------------------------------------------- if / for
    private Object[] parseCond(String s) {
        boolean ign = false, not = false; s = s.trim();
        if (s.toLowerCase(Locale.ROOT).startsWith("/i ")) { ign = true; s = s.substring(3).trim(); }
        if (s.toLowerCase(Locale.ROOT).startsWith("not ")) { not = true; s = s.substring(4).trim(); }
        boolean res; String rest;
        String[] sf = splitFirst(s); String w = sf[0].toLowerCase(Locale.ROOT);
        if (w.equals("exist")) {
            String[] p = splitFirst(sf[1]);
            res = !glob(p[0]).isEmpty(); rest = p[1];
        } else if (w.equals("errorlevel")) {
            String[] p = splitFirst(sf[1]);
            int n = 0; try { n = Integer.parseInt(p[0]); } catch (Exception e) { }
            res = errorLevel >= n; rest = p[1];
        } else if (w.equals("defined")) {
            String[] p = splitFirst(sf[1]);
            res = vars.containsKey(p[0].toUpperCase(Locale.ROOT)); rest = p[1];
        } else {
            int idx = indexOfUnquoted(s, "==");
            if (idx < 0) { out.println("Unsupported if condition: " + s); return new Object[]{Boolean.FALSE, ""}; }
            String left = unq(s.substring(0, idx).trim());
            String[] p = splitFirst(s.substring(idx + 2).trim());
            res = ign ? left.equalsIgnoreCase(p[0]) : left.equals(p[0]); rest = p[1];
        }
        if (not) res = !res;
        return new Object[]{Boolean.valueOf(res), rest};
    }

    private void ifLine(Frame f, String s) {
        Object[] c = parseCond(s);
        boolean ok = (Boolean) c[0]; String rest = ((String) c[1]).trim();
        if (rest.startsWith("(")) {
            int d = 0, end = -1; boolean q = false;
            for (int i = 0; i < rest.length(); i++) {
                char ch = rest.charAt(i);
                if (ch == '"') q = !q;
                else if (!q && ch == '(') d++;
                else if (!q && ch == ')') { d--; if (d == 0) { end = i; break; } }
            }
            if (end < 0) end = rest.length();
            String thenT = rest.substring(1, end).trim();
            String after = end + 1 <= rest.length() ? rest.substring(Math.min(end + 1, rest.length())).trim() : "";
            String elseT = "";
            if (after.toLowerCase(Locale.ROOT).startsWith("else")) {
                elseT = after.substring(4).trim();
                if (elseT.startsWith("(") && elseT.endsWith(")")) elseT = elseT.substring(1, elseT.length() - 1).trim();
            }
            execChain(f, ok ? thenT : elseT);
        } else if (ok) execChain(f, rest);
    }

    private void forLine(Frame f, String line, List<String> block) {
        Matcher m = Pattern.compile("(?is)^for\\s+(/f\\s+(?:\"[^\"]*\"\\s+)?)?%%(\\w)\\s+in\\s+\\((.*)\\)\\s+do\\s*(.*)$").matcher(line.trim());
        if (!m.find()) { out.println("Unsupported for loop: " + line); return; }
        String fopt = m.group(1); char var = m.group(2).charAt(0);
        String set = m.group(3).trim(), doCmd = m.group(4);
        List<String> items = new ArrayList<String>();
        if (fopt != null) {
            boolean whole = fopt.contains("delims=");
            List<String> src = new ArrayList<String>();
            if (set.startsWith("'")) {
                final List<String> cap = new ArrayList<String>();
                Out saved = cur;
                cur = new Out() { public void println(String s) { cap.add(s); } public void clear() { } };
                try { execChain(f, unq(set.substring(1, set.endsWith("'") ? set.length() - 1 : set.length()))); }
                finally { cur = saved; }
                src.addAll(cap);
            } else if (set.startsWith("\"")) src.add(unq(set));
            else try { src.addAll(readLines(toFile(set))); } catch (IOException e) { out.println("File not found: " + set); }
            for (String s : src) {
                if (whole) { if (!s.isEmpty()) items.add(s); }
                else { List<String> t = toks(s); if (!t.isEmpty()) items.add(t.get(0)); }
            }
        } else {
            for (String t : toks(set)) {
                if (t.indexOf('*') >= 0 || t.indexOf('?') >= 0) {
                    int bs = Math.max(t.lastIndexOf('\\'), t.lastIndexOf('/'));
                    String pre = bs >= 0 ? t.substring(0, bs + 1) : "";
                    for (File x : glob(t)) items.add(pre + x.getName());
                } else items.add(t);
            }
        }
        Character key = Character.valueOf(var); String old = forVars.get(key);
        try {
            for (String it : items) {
                if (halt) break;
                forVars.put(key, it);
                if (block != null) execLines(f, block, 0);
                else execChain(f, expand(doCmd, f));
            }
        } finally { if (old == null) forVars.remove(key); else forVars.put(key, old); }
    }

    // ---------------------------------------------------------------- file helpers
    private List<File> glob(String pat) {
        File full = toFile(pat); List<File> r = new ArrayList<File>(); String name = full.getName();
        if (name.indexOf('*') < 0 && name.indexOf('?') < 0) { if (full.exists()) r.add(full); return r; }
        File dir = full.getParentFile();
        if (dir == null || !dir.isDirectory()) return r;
        Pattern p = Pattern.compile(wild(name), Pattern.CASE_INSENSITIVE);
        File[] ls = dir.listFiles();
        if (ls != null) { Arrays.sort(ls); for (File x : ls) if (p.matcher(x.getName()).matches()) r.add(x); }
        return r;
    }

    private static void copyFile(File a, File b) throws IOException {
        File p = b.getParentFile(); if (p != null) p.mkdirs();
        InputStream i = new FileInputStream(a); OutputStream o = new FileOutputStream(b);
        try { byte[] buf = new byte[65536]; int n; while ((n = i.read(buf)) > 0) o.write(buf, 0, n); }
        finally { i.close(); o.close(); }
    }

    private static void copyTree(File a, File b) throws IOException {
        if (a.isDirectory()) {
            b.mkdirs(); File[] ls = a.listFiles();
            if (ls != null) for (File x : ls) copyTree(x, new File(b, x.getName()));
        } else copyFile(a, b);
    }

    private static boolean deleteTree(File f) {
        if (f.isDirectory()) { File[] ls = f.listFiles(); if (ls != null) for (File x : ls) deleteTree(x); }
        return f.delete();
    }

    private void emit(String s) { cur.println(s); }

    private File resolveScript(String name, Frame f) {
        String[] exts = {"", ".bat", ".cmd"};
        List<File> bases = new ArrayList<File>();
        bases.add(toFile(name));
        if (f.file != null && f.file.getParentFile() != null)
            bases.add(norm(new File(f.file.getParentFile(), unq(name).replace('\\', '/'))));
        for (File b : bases)
            for (String e : exts) {
                File c = new File(b.getPath() + e);
                String l = c.getName().toLowerCase(Locale.ROOT);
                if (c.isFile() && (l.endsWith(".bat") || l.endsWith(".cmd"))) return c;
            }
        return null;
    }

    // ---------------------------------------------------------------- builtin commands
    private void builtin(Frame f, String part) {
        String line = part.trim();
        if (line.isEmpty()) return;
        String target = null; boolean app = false;
        int gt = indexOfUnquoted(line, ">");
        if (gt >= 0) {
            String t = line.substring(gt + 1);
            if (t.startsWith(">")) { app = true; t = t.substring(1); }
            target = unq(t.trim());
            line = line.substring(0, gt).replaceAll("\\s+\\d$", "").trim();
        }
        final String ln = line;
        final Frame fr = f;
        if (target == null) { run1(fr, ln); return; }
        withRedirect(target, app, new Runnable() { public void run() { run1(fr, ln); } });
    }

    private void run1(Frame f, String line) {
        String[] sf = splitFirst(line); String cmd = sf[0], rest = sf[1];
        String lc = cmd.toLowerCase(Locale.ROOT);
        if (lc.equals("echo") || lc.startsWith("echo.") || lc.startsWith("echo(")) {
            if (lc.equals("echo")) {
                String r = rest.toLowerCase(Locale.ROOT);
                if (r.isEmpty()) emit("ECHO is " + (echoOn ? "on." : "off."));
                else if (r.equals("off")) echoOn = false;
                else if (r.equals("on")) echoOn = true;
                else emit(unescape(rest));
            } else emit(unescape(line.substring(5)));
            return;
        }
        if (lc.equals("rem") || lc.equals("::")) return;
        if (lc.matches("^[a-z]:$")) return;
        errorLevelSetOk(lc);
        if (lc.equals("set")) { doSet(rest); return; }
        if (lc.equals("cd") || lc.equals("chdir") || lc.equals("cd..")) {
            if (lc.equals("cd..")) { File p = cwd.getParentFile(); if (p != null && winPath(cwd).length() > 3) cwd = p; return; }
            String r = rest; if (r.toLowerCase(Locale.ROOT).startsWith("/d")) r = r.substring(2).trim();
            if (r.isEmpty()) { emit(winPath(cwd)); return; }
            File t = toFile(r);
            if (t.isDirectory()) cwd = t; else { emit("The system cannot find the path specified."); errorLevel = 1; }
            return;
        }
        if (lc.equals("mkdir") || lc.equals("md")) {
            for (String t : toks(rest)) if (!t.startsWith("/")) toFile(t).mkdirs();
            return;
        }
        if (lc.equals("rmdir") || lc.equals("rd")) {
            boolean s = false;
            for (String t : toks(rest)) {
                if (t.equalsIgnoreCase("/s")) s = true;
                else if (!t.startsWith("/")) {
                    File d = toFile(t);
                    if (!d.isDirectory()) { emit("The system cannot find the file specified."); errorLevel = 1; }
                    else if (s) deleteTree(d);
                    else if (!d.delete()) { emit("The directory is not empty."); errorLevel = 1; }
                }
            }
            return;
        }
        if (lc.equals("del") || lc.equals("erase")) {
            for (String t : toks(rest)) {
                if (t.startsWith("/")) continue;
                List<File> g = glob(t);
                if (g.isEmpty()) { emit("Could Not Find " + winPath(toFile(t))); errorLevel = 1; }
                for (File x : g) if (x.isFile()) x.delete();
            }
            return;
        }
        if (lc.equals("copy") || lc.equals("xcopy") || lc.equals("move") || lc.equals("ren") || lc.equals("rename")) {
            List<String> a = new ArrayList<String>();
            for (String t : toks(rest)) if (!t.startsWith("/")) a.add(t);
            if (a.size() < 2) { emit("The syntax of the command is incorrect."); errorLevel = 1; return; }
            String dst = a.get(1);
            List<File> srcs = glob(a.get(0));
            if (srcs.isEmpty()) { emit("The system cannot find the file specified."); errorLevel = 1; return; }
            File d = toFile(dst);
            try {
                int n = 0;
                for (File s : srcs) {
                    boolean ren = lc.equals("ren") || lc.equals("rename");
                    File out2;
                    if (ren) out2 = new File(s.getParentFile(), dst);
                    else if (d.isDirectory() || dst.endsWith("\\") || dst.endsWith("/")) {
                        if (s.isDirectory() && lc.equals("xcopy")) out2 = d; else out2 = new File(d, s.getName());
                    } else out2 = d;
                    if (lc.equals("move") || ren) { if (!s.renameTo(out2)) { copyTree(s, out2); deleteTree(s); } }
                    else copyTree(s, out2);
                    n++;
                }
                if (lc.equals("copy") || lc.equals("xcopy")) emit("        " + n + " file(s) copied.");
            } catch (IOException e) { emit("Access is denied."); errorLevel = 1; }
            return;
        }
        if (lc.equals("type")) {
            for (String t : toks(rest)) {
                try { for (String s : readLines(toFile(t))) emit(s); }
                catch (IOException e) { emit("The system cannot find the file specified."); errorLevel = 1; }
            }
            return;
        }
        if (lc.equals("dir")) { doDir(rest); return; }
        if (lc.equals("cls")) { cur.clear(); return; }
        if (lc.equals("pause")) { emit("Press any key to continue . . ."); return; }
        if (lc.equals("ver")) { emit("Microsoft Windows [emulated by BatRun]"); return; }
        if (lc.equals("title") || lc.equals("color") || lc.equals("chcp") || lc.equals("mode") || lc.equals("prompt")
                || lc.equals("setlocal") || lc.equals("endlocal") || lc.equals("timeout") || lc.equals("popd") || lc.equals("pushd")) return;
        if (lc.equals("exit")) {
            boolean local = false; int code = 0;
            for (String t : toks(rest)) {
                if (t.equalsIgnoreCase("/b")) local = true;
                else try { code = Integer.parseInt(t); } catch (Exception e) { }
            }
            errorLevel = code;
            if (!local) halt = true;
            throw new ExitEx();
        }
        if (lc.equals("goto")) {
            String l = rest.trim().toLowerCase(Locale.ROOT);
            if (l.startsWith(":")) l = l.substring(1);
            l = l.split("\\s+")[0];
            if (l.equals("eof") || l.isEmpty()) throw new ExitEx();
            throw new GotoEx(l);
        }
        if (lc.equals("call")) { doCall(f, rest); return; }
        if (lc.equals("start")) {
            List<String> a = new ArrayList<String>();
            for (String t : toks(rest)) if (!t.startsWith("/") && !t.isEmpty()) a.add(t);
            if (a.isEmpty()) return;
            File s = resolveScript(a.get(0), f);
            if (s != null) { a.remove(0); runNested(s, a); }
            else { emit("'" + a.get(0) + "' cannot run on Android (Windows programs need Winlator)."); errorLevel = 9009; }
            return;
        }
        // a script called by name
        File s = resolveScript(cmd, f);
        if (s != null) { runNested(s, toks(rest)); return; }
        emit("'" + cmd + "' cannot run here: Windows programs (.exe) are not available on Android.");
        errorLevel = 9009;
    }

    private void errorLevelSetOk(String lc) {
        if (!lc.equals("if") && !lc.equals("call") && !lc.equals("exit") && !lc.equals("goto") && !lc.equals("echo")
                && !lc.equals("pause") && !lc.equals("set") && !lc.equals("cls")) errorLevel = 0;
    }

    private void runNested(File s, List<String> args) {
        try { runScriptFile(s, args); } catch (IOException e) { emit("Could not read " + s.getName()); errorLevel = 1; }
    }

    private void doCall(Frame f, String rest) {
        String[] sf = splitFirst(rest);
        if (sf[0].startsWith(":")) {
            String name = sf[0].substring(1).toLowerCase(Locale.ROOT);
            Integer idx = f.labels.get(name);
            if (idx == null) { emit("The system cannot find the batch label specified - " + name); errorLevel = 1; return; }
            List<String> a = toks(sf[1]);
            String[] args = new String[Math.max(10, a.size() + 1)];
            args[0] = ":" + name;
            for (int i = 0; i < a.size(); i++) args[i + 1] = a.get(i);
            if (depth > 40) { emit("Too many nested calls."); return; }
            depth++;
            try { runFrame(new Frame(f, args), idx + 1); } finally { depth--; }
            return;
        }
        File s = resolveScript(sf[0], f);
        if (s != null) { runNested(s, toks(sf[1])); return; }
        emit("'" + sf[0] + "' cannot run here: Windows programs (.exe) are not available on Android.");
        errorLevel = 9009;
    }

    private void doDir(String rest) {
        boolean bare = false; String path = null;
        for (String t : toks(rest)) {
            if (t.startsWith("/")) { if (t.equalsIgnoreCase("/b")) bare = true; } else path = t;
        }
        List<File> items = new ArrayList<File>();
        if (path == null) addAllSorted(items, cwd);
        else if (path.indexOf('*') >= 0 || path.indexOf('?') >= 0) items = glob(path);
        else {
            File pf = toFile(path);
            if (pf.isDirectory()) addAllSorted(items, pf); else if (pf.exists()) items.add(pf);
        }
        if (items.isEmpty()) { emit("File Not Found"); errorLevel = 1; return; }
        for (File x : items)
            emit(bare ? x.getName() : (x.isDirectory() ? "<DIR>          " : String.format(Locale.ROOT, "%14d ", x.length())) + x.getName());
    }

    private static void addAllSorted(List<File> items, File dir) {
        File[] ls = dir.listFiles();
        if (ls != null) { Arrays.sort(ls); items.addAll(Arrays.asList(ls)); }
    }

    private void doSet(String rest) {
        String lr = rest.toLowerCase(Locale.ROOT);
        if (rest.isEmpty()) { List<String> k = new ArrayList<String>(vars.keySet()); Collections.sort(k); for (String s : k) emit(s + "=" + vars.get(s)); return; }
        if (lr.startsWith("/p")) { emit("set /p (asking for input) is not supported."); return; }
        if (lr.startsWith("/a")) {
            String e = unq(rest.substring(2).trim()); int eq = e.indexOf('=');
            try {
                if (eq > 0) {
                    String name = e.substring(0, eq).trim(), op = "";
                    if (name.length() > 0 && "+-*/%".indexOf(name.charAt(name.length() - 1)) >= 0) {
                        op = name.substring(name.length() - 1); name = name.substring(0, name.length() - 1).trim();
                    }
                    String ex = e.substring(eq + 1);
                    if (!op.isEmpty()) ex = "(" + lookupNum(name) + ")" + op + "(" + ex + ")";
                    long v = new Calc(ex).run();
                    vars.put(name.toUpperCase(Locale.ROOT), String.valueOf(v));
                } else emit(String.valueOf(new Calc(e).run()));
            } catch (Exception ex) { emit("Invalid number or expression."); errorLevel = 1; }
            return;
        }
        String s = rest;
        if (s.startsWith("\"") && s.endsWith("\"") && s.length() >= 2) s = s.substring(1, s.length() - 1);
        int eq = s.indexOf('=');
        if (eq < 0) {
            for (Map.Entry<String, String> en : new TreeMap<String, String>(vars).entrySet())
                if (en.getKey().startsWith(s.toUpperCase(Locale.ROOT))) emit(en.getKey() + "=" + en.getValue());
            return;
        }
        String k = s.substring(0, eq).trim().toUpperCase(Locale.ROOT), v = s.substring(eq + 1);
        if (v.isEmpty()) vars.remove(k); else vars.put(k, v);
    }

    private String lookupNum(String name) {
        String v = vars.get(name.toUpperCase(Locale.ROOT));
        return v == null || v.isEmpty() ? "0" : v;
    }

    /** tiny integer calculator for set /a */
    private class Calc {
        final String s; int p = 0;
        Calc(String s) { this.s = s; }
        long run() { long v = expr(); ws(); if (p < s.length()) throw new RuntimeException(); return v; }
        void ws() { while (p < s.length() && s.charAt(p) == ' ') p++; }
        long expr() {
            long v = term();
            for (;;) { ws(); if (p < s.length() && s.charAt(p) == '+') { p++; v += term(); } else if (p < s.length() && s.charAt(p) == '-') { p++; v -= term(); } else return v; }
        }
        long term() {
            long v = factor();
            for (;;) {
                ws();
                if (p < s.length() && s.charAt(p) == '*') { p++; v *= factor(); }
                else if (p < s.length() && s.charAt(p) == '/') { p++; long d = factor(); v = v / d; }
                else if (p < s.length() && s.charAt(p) == '%') { p++; long d = factor(); v = v % d; }
                else return v;
            }
        }
        long factor() {
            ws();
            if (p >= s.length()) throw new RuntimeException();
            char c = s.charAt(p);
            if (c == '-') { p++; return -factor(); }
            if (c == '(') { p++; long v = expr(); ws(); if (p >= s.length() || s.charAt(p) != ')') throw new RuntimeException(); p++; return v; }
            int st = p;
            if (Character.isDigit(c)) { while (p < s.length() && Character.isDigit(s.charAt(p))) p++; return Long.parseLong(s.substring(st, p)); }
            while (p < s.length() && (Character.isLetterOrDigit(s.charAt(p)) || s.charAt(p) == '_')) p++;
            if (st == p) throw new RuntimeException();
            return Long.parseLong(lookupNum(s.substring(st, p)));
        }
    }
}
