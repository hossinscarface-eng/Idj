# BatRun

A tiny Android app (about 700 lines, no libraries) that:
- runs `.bat` / `.cmd` files and single commands (type them in the box at the bottom),
- shows `.md`, `.txt`, `.cs`, `.info` and other text files,
- has a simple file browser. Tap a script to Run or View it.

C:\ (and every other drive letter) maps to the root folder you type at the top
(default `/storage/emulated/0/Greymeat`). `%~dp0`, `%1`, `set`, `set /a`, `if`/`else`, `for`, `for /f`,
`goto`, `call :label`, `&`/`&&`/`||`, `> file` redirects, `copy`, `xcopy`, `move`, `ren`, `del`, `md`, `rd`,
`type`, `dir`, `cd` and `exit /b` are emulated.
**Windows programs (`.exe`, such as `csc.exe`) cannot run on Android.** BatRun says so instead of failing silently.
So `BUILD-MODS.cmd` will stop at the compiler check. Compile mods on a PC.

## Get the APK (easiest, no PC software)
1. Make a free GitHub account, create a new repository, and upload everything in this folder
   (keep `.github/workflows/build.yml`).
2. Open the repository's **Actions** tab. The "Build APK" run starts by itself (about 3 minutes).
3. Open the finished run and download **BatRun-apk**, unzip it, install `app-debug.apk`
   (allow "install unknown apps"), then allow "All files access" when the app asks.

## Or build in Android Studio
Open this folder, wait for the Gradle sync, then Build > Build APK(s).

## Status
The script interpreter (`BatRunner.java`) was compiled and tested on a PC with a feature script and
your BUILD-MODS.cmd. The Android screen (`MainActivity.java`) and the Gradle files were not built
here. If the build prints an error, send it to me.
